# Guia Operacional de Saúde Mental — UBS 3 Paranoá Parque

Site estático para publicação no GitHub Pages.

## Estrutura

- `index.html`: página principal do guia.
- `documentos/`: PDFs locais vinculados pelo guia.
- `.nojekyll`: instrui o GitHub Pages a publicar os arquivos estáticos sem processamento Jekyll.

## Publicar com GitHub Pages

1. Crie um repositório no GitHub.
2. Envie **o conteúdo desta pasta** para a raiz do repositório (não envie o ZIP compactado como único arquivo).
3. No repositório, abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch principal (por exemplo, `main`) e a pasta `/(root)`, depois salve.
6. Aguarde a publicação indicada pelo GitHub Pages e acesse o endereço fornecido nas configurações.

Mantenha a pasta `documentos/` junto ao `index.html`; os links para os PDFs usam caminhos relativos.
